package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class OPiece extends TetrominoBase { // Inheritance
    private static final int[][][] O_SHAPES = {
            {
                    {1, 1},
                    {1, 1},
            }
    };

    public OPiece() {
        super(O_SHAPES, TetrominoColor.YELLOW);
    }
}

