package ph.edu.dlsu.lbycpei.tetris.model;

public interface GameModelListener {
    void onModelChanged();
}

