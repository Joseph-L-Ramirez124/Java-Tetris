package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public enum TetrominoType {
    I, O, T, S, Z, J, L
}