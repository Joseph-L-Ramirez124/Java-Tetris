package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class SPiece extends TetrominoBase { // Inheritance
    private static final int[][][] S_SHAPES = {
            { // first rotation of the piece
                    {0, 1, 1},
                    {1, 1, 0}
            },
            { // second rotation of the piece
                    {1, 0},
                    {1, 1},
                    {0, 1}
            }
    };

    public SPiece() {
        super(S_SHAPES, TetrominoColor.RED);
    }
}