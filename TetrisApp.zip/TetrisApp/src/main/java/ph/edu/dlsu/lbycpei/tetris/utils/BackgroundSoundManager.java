package ph.edu.dlsu.lbycpei.tetris.utils;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.util.Objects;

/**
 * This class is responsible for playing the background sound
 */
public class BackgroundSoundManager {

    private MediaPlayer mediaPlayer;

    public void playLoopingSound(String audioFile) {
        try {
            // Create Media object from the audio file
            Media sound = new Media(Objects.requireNonNull(getClass().getResource(SoundConfig.SOUND_PATH + audioFile)).toExternalForm());

            // Create MediaPlayer and set it to loop indefinitely
            mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE); // Loop forever
            mediaPlayer.play();
            // Sound volume control
            double volume = 0.25;
            mediaPlayer.setVolume(volume);
        } catch (Exception e) {
            System.err.println("Error loading audio file: " + e.getMessage());
        }
    }

    // Toggle between play/pause
    public void togglePlayPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.play();
            }
        }
    }

    public void stopLoopingSound() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.dispose();
            mediaPlayer = null;
        }
    }
}
