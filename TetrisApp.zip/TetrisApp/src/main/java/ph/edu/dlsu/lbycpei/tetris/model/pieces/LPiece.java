package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class LPiece extends TetrominoBase { // Inheritance
    private static final int[][][] L_SHAPES = {
            { // first rotation of the piece
                    {0, 0, 1},
                    {1, 1, 1},
                    {0, 0, 0}
            },
            { // second rotation of the piece
                    {0, 1, 0},
                    {0, 1, 0},
                    {0, 1, 1}
            },
            { // third rotation of the piece
                    {0, 0, 0},
                    {1, 1, 1},
                    {1, 0, 0}
            },
            {  // fourth rotation of the piece
                    {1, 1, 0},
                    {0, 1, 0},
                    {0, 1, 0}
            }
    };

    public LPiece() {
        super(L_SHAPES, TetrominoColor.ORANGE);
    }
}
