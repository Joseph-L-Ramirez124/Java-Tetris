package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class ZPiece extends TetrominoBase { // Inheritance
    private static final int[][][] Z_SHAPES = {
            { // first rotation of the piece
                    {1, 1, 0},
                    {0, 1, 1}
            },
            { // second rotation of the piece
                    {0, 1},
                    {1, 1},
                    {1, 0}
            }
    };

    public ZPiece() {
        super(Z_SHAPES, TetrominoColor.CYAN);
    }
}