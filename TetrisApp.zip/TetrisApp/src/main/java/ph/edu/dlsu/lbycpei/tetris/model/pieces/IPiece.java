package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class IPiece extends TetrominoBase { // Inheritance
    private static final int[][][] J_SHAPES = {
            { // first rotation of the piece
                    {0, 0, 0, 0},
                    {1, 1, 1, 1},
                    {0, 0, 0, 0},
                    {0, 0, 0, 0}
            },
            { // second rotation of the piece
                    {0, 1, 0, 0},
                    {0, 1, 0, 0},
                    {0, 1, 0, 0},
                    {0, 1, 0, 0}
            }

    };

    public IPiece() {
        super(J_SHAPES, TetrominoColor.BLUE);
    }
}
