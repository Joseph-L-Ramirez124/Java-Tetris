package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class JPiece extends TetrominoBase { // Inheritance
    private static final int[][][] J_SHAPES = {
            { // first rotation of the piece
                    {1, 0, 0},
                    {1, 1, 1},
                    {0, 0, 0}
            },
            { // second rotation of the piece
                    {0, 1, 0},
                    {0, 1, 0},
                    {1, 1, 0}
            },
            { // third rotation of the piece
                    {0, 0, 0},
                    {1, 1, 1},
                    {0, 0, 1}
            },
            {  // fourth rotation of the piece
                    {0, 1, 1},
                    {0, 1, 0},
                    {0, 1, 0}
            }
    };

    public JPiece() {
        super(J_SHAPES, TetrominoColor.GREEN);
    }
}