package ph.edu.dlsu.lbycpei.tetris.model.pieces;

public class TPiece extends TetrominoBase { // Inheritance
    private static final int[][][] T_SHAPES = {
            { // first rotation of the piece
                    {1, 1, 1},
                    {0, 1, 0},
                    {0, 1, 0}
            },
            { // second rotation of the piece
                    {1, 0, 0},
                    {1, 1, 1},
                    {1, 0, 0}
            },
            { // third rotation of the piece
                    {0, 1, 0},
                    {0, 1, 0},
                    {1, 1, 1}
            },
            {  // fourth rotation of the piece
                    {0, 0, 1},
                    {1, 1, 1},
                    {0, 0, 1}
            }
    };

    public TPiece() {
        super(T_SHAPES, TetrominoColor.PURPLE);
    }
}
