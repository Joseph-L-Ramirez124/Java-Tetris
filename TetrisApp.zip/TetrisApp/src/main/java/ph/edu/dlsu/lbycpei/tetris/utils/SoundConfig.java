package ph.edu.dlsu.lbycpei.tetris.utils;

/**
 * This config file handles constants related to sounds
 */
public class SoundConfig {
    public static final String SOUND_PATH = "/audio/";
    public static final String BACKGROUND_MUSIC = "music.mp3";
}