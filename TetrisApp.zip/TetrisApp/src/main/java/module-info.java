module ph.edu.dlsu.lbycpei.tetris {
    requires javafx.controls;
    requires javafx.media;

    exports ph.edu.dlsu.lbycpei.tetris;
    exports ph.edu.dlsu.lbycpei.tetris.controller;
    exports ph.edu.dlsu.lbycpei.tetris.view;
    exports ph.edu.dlsu.lbycpei.tetris.model;
    exports ph.edu.dlsu.lbycpei.tetris.model.pieces;
}